

# 适用于：泥石流冲出/未冲出二分类响应
#
# 数据结构：
# 第1列：是否冲出，1=冲出，0=未冲出
# 第2列以后：控制因子
#
# 输出内容：
# 1. BKMR模型文件
# 2. 单变量响应图：单图 + 组合图
# 3. 双变量响应面：所有两两组合，单图 + 组合图
# 4. 条件双变量响应曲线：所有两两组合，单图 + 组合图
# 5. 单变量风险摘要图
# 6. 每张图对应的 Origin 可复现 Excel 数据
# 7. 总 Excel 汇总文件
# ============================================================

rm(list = ls())

# ============================================================
# 0. 加载必要 R 包
# ============================================================

pkgs <- c("bkmr", "ggplot2", "readxl", "dplyr", "openxlsx", "tidyr", "coda")

for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, dependencies = TRUE)
  }
}

library(bkmr)
library(ggplot2)
library(readxl)
library(dplyr)
library(openxlsx)
library(tidyr)
library(grid)

# ============================================================
# 1. 基本参数设置
# ============================================================

work_dir <- "F:/1.自己的论文/11.泥石流冲出预测/计算文件/BKMR"

# 训练迭代次数。
iter_num <- 1000


RUN_THRESHOLD_REVIEW <- TRUE
THRESHOLD_VARIABLES <- c("B", "C", "D", "I")
THRESHOLD_BURN_FRACTION <- 0.50
THRESHOLD_POST_DRAWS <- 500L   # 最多选用500个后半链状态；不是ESS
THRESHOLD_POST_SEED <- 730111L
THRESHOLD_BOOT_REPS <- 20L    # 首次调试可设5；少量重复不能作为正式区间
THRESHOLD_BOOT_ITER <- iter_num
THRESHOLD_BOOT_METHOD <- "approx"  # 与原稿响应曲线的汇总方法一致
THRESHOLD_BOOT_SEED <- 830111L
THRESHOLD_SAVE_BOOT_MODELS <- FALSE  # TRUE会占用更多磁盘空间
THRESHOLD_RETRY_FAILURES <- TRUE
REUSE_COMPATIBLE_MODEL <- TRUE
EXISTING_MODEL_FILE <- ""     # 可填实际原模型的完整路径；留空则使用新目录缓存/训练
# ===== 以上为新增设置 =====

# 是否对某些变量进行 log1p 变换。
# 当前默认不做 log 变换。
# 如果后续只对 C 做 log1p，可改为：LOG_VARS <- c("C")
LOG_VARS <- character(0)

# 是否填满双变量响应面中的灰色区域。
# TRUE：图面完整，适合论文展示，但边界区域属于模型外推，应谨慎解释。
# FALSE：保留灰色遮罩，更保守。
FILL_GREY_AREAS <- TRUE

if (FILL_GREY_AREAS) {
  MIN_PLOT_DIST <- Inf
} else {
  MIN_PLOT_DIST <- 1
}

# 数值稳定性扰动
jitter_sd <- 1e-7

# 随机种子
set.seed(111)

# 输出目录
if (!dir.exists(work_dir)) {
  stop("工作路径不存在，请检查 work_dir 是否正确。")
}

setwd(work_dir)

out_dir <- file.path(work_dir, paste0("BKMR_", iter_num, "_threshold_review"))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

model_dir <- file.path(out_dir, "00_model")
data_dir <- file.path(out_dir, "01_origin_data")
fig_dir <- file.path(out_dir, "02_figures")

univar_single_fig_dir <- file.path(fig_dir, "univariate_single")
bivar_single_fig_dir <- file.path(fig_dir, "bivariate_single")
cond_single_fig_dir <- file.path(fig_dir, "conditional_bivariate_single")

univar_single_data_dir <- file.path(data_dir, "univariate_single")
bivar_single_data_dir <- file.path(data_dir, "bivariate_single")
cond_single_data_dir <- file.path(data_dir, "conditional_bivariate_single")

dirs <- c(
  model_dir, data_dir, fig_dir,
  univar_single_fig_dir, bivar_single_fig_dir, cond_single_fig_dir,
  univar_single_data_dir, bivar_single_data_dir, cond_single_data_dir
)

for (d in dirs) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

cat("输出路径：", out_dir, "\n")

# ============================================================
# 2. 读取原始数据
# ============================================================

# 优先读取指定文件名；如果不存在，则读取文件夹内第一个 Excel。
preferred_file <- file.path(work_dir, "训练样本.xlsx")

if (!file.exists(preferred_file)) {
  stop("未找到训练样本。请将preferred_file改为实际训练数据的完整路径；不会自动读取其他Excel。")
}
file_path <- preferred_file

cat("当前读取文件：", file_path, "\n")

dat_raw <- read_excel(file_path, sheet = 1)
dat <- as.data.frame(dat_raw)

if (ncol(dat) < 2) {
  stop("表格至少需要两列：第1列为标签，第2列以后为控制因子。")
}

cat("原始变量名：\n")
print(names(dat))

# 转换为数值
to_num <- function(x) {
  as.numeric(gsub(",", "", trimws(as.character(x))))
}

dat[] <- lapply(dat, to_num)

n_before <- nrow(dat)
dat <- dat[complete.cases(dat), ]
n_after <- nrow(dat)

cat("原始样本数：", n_before, "\n")
cat("删除缺失或非数值后样本数：", n_after, "\n")

# 第一列为响应变量
y <- as.numeric(dat[[1]])

if (!all(y %in% c(0, 1))) {
  stop("第一列必须为0/1变量，其中1表示冲出，0表示未冲出。")
}

# 后续列为解释变量
Z_raw <- as.data.frame(dat[, -1, drop = FALSE])
names(Z_raw) <- as.character(names(Z_raw))
variable_names <- colnames(Z_raw)
if (!identical(variable_names, c("B", "C", "D", "F", "H", "I"))) {
  stop("为对应本文六变量模型，解释变量列必须依次为 B,C,D,F,H,I；请先核对训练数据。")
}


cat("进入BKMR的解释变量：\n")
print(variable_names)

cat("冲出/未冲出样本数：\n")
print(table(y))

# ============================================================
# 3. 变量标签设置
# ============================================================

var_label_map <- c(
  "A" = "6-h cumulative rainfall",
  "B" = "24-h cumulative rainfall",
  "C" = "Source-area ratio",
  "D" = "CKAI",
  "E" = "Catchment area",
  "F" = "Catchment relief",
  "G" = "Melton ratio",
  "H" = "Circularity ratio",
  "I" = "Longitudinal channel gradient"
)

var_axis_map <- c(
  "A" = "6-h cumulative rainfall (mm)",
  "B" = "24-h cumulative rainfall (mm)",
  "C" = "Source-area ratio",
  "D" = "CKAI",
  "E" = "Catchment area",
  "F" = "Catchment relief (m)",
  "G" = "Melton ratio",
  "H" = "Circularity ratio",
  "I" = "Longitudinal channel gradient"
)

label_var <- function(x) {
  x <- as.character(x)
  ifelse(x %in% names(var_label_map), var_label_map[x], x)
}

axis_label_var <- function(x) {
  x <- as.character(x)
  ifelse(x %in% names(var_axis_map), var_axis_map[x], x)
}

# 三类因子分组仅用于记录，不再进行组交互分析
rain_names <- intersect(c("A", "B"), variable_names)
source_names <- intersect(c("C", "D"), variable_names)
terrain_names <- intersect(c("E", "F", "G", "H", "I"), variable_names)

cat("降雨因子：\n")
print(rain_names)

cat("物源因子：\n")
print(source_names)

cat("地形沟道因子：\n")
print(terrain_names)

# ============================================================
# 4. 数据诊断
# ============================================================

diag_file <- file.path(out_dir, "data_diagnosis.txt")
sink(diag_file)

cat("1. 冲出/未冲出样本数量：\n")
print(table(y))

cat("\n2. 各变量按冲出/未冲出分组的统计特征：\n")
for (v in names(Z_raw)) {
  cat("\n变量：", v, "\n")
  print(tapply(Z_raw[[v]], y, summary))
}

cat("\n3. 完全重复的解释变量组合数量：\n")
print(sum(duplicated(Z_raw)))

cat("\n4. Spearman 相关系数矩阵：\n")
print(round(cor(Z_raw, use = "complete.obs", method = "spearman"), 3))

cat("\n5. 各变量标准差：\n")
print(apply(Z_raw, 2, sd, na.rm = TRUE))

sink()

cat("数据诊断结果已保存至：", diag_file, "\n")

# ============================================================
# 5. 数据标准化与反标准化函数
# ============================================================

Z_model_for_scaling <- Z_raw

if (length(LOG_VARS) > 0) {
  for (v in intersect(LOG_VARS, names(Z_model_for_scaling))) {
    if (min(Z_model_for_scaling[[v]], na.rm = TRUE) >= 0) {
      Z_model_for_scaling[[v]] <- log1p(Z_model_for_scaling[[v]])
      cat("已对变量进行 log1p 转换：", v, "\n")
    } else {
      warning("变量 ", v, " 存在负值，未进行 log1p。")
    }
  }
} else {
  cat("本次训练不进行 log1p 变换。\n")
}

scale_center <- sapply(Z_model_for_scaling, mean, na.rm = TRUE)
scale_sd <- sapply(Z_model_for_scaling, sd, na.rm = TRUE)

Z_scaled <- scale(Z_model_for_scaling)
Z_scaled <- as.matrix(Z_scaled)
colnames(Z_scaled) <- names(Z_model_for_scaling)

if (any(!is.finite(Z_scaled))) {
  stop("标准化后 Z 中存在 NA/Inf，请检查是否有零方差变量。")
}

# 加入极小扰动提高数值稳定性
Z <- Z_scaled + matrix(
  rnorm(length(Z_scaled), mean = 0, sd = jitter_sd),
  nrow = nrow(Z_scaled),
  ncol = ncol(Z_scaled)
)

colnames(Z) <- colnames(Z_scaled)

write.csv(
  data.frame(y = y, Z),
  file = file.path(data_dir, "BKMR_input_standardized_for_model.csv"),
  row.names = FALSE
)

write.xlsx(
  data.frame(
    Variable = names(scale_center),
    Label = label_var(names(scale_center)),
    Center = as.numeric(scale_center),
    SD = as.numeric(scale_sd),
    Log1p_used = names(scale_center) %in% LOG_VARS
  ),
  file = file.path(data_dir, "standardization_parameters.xlsx"),
  overwrite = TRUE
)

inverse_z_to_raw <- function(var_name, z_value) {
  var_name <- as.character(var_name)
  x_trans <- z_value * scale_sd[var_name] + scale_center[var_name]
  
  if (var_name %in% LOG_VARS) {
    return(expm1(x_trans))
  } else {
    return(x_trans)
  }
}

# ============================================================
# 6. 训练 BKMR 模型
# ============================================================

cat("\n============================================================\n")
cat("开始拟合二分类 probit BKMR 模型\n")
cat("iter_num =", iter_num, "\n")
cat("family = binomial\n")
cat("est.h = TRUE\n")
cat("varsel = FALSE\n")
cat("MIN_PLOT_DIST =", MIN_PLOT_DIST, "\n")
cat("============================================================\n")

set.seed(111)

model_file <- file.path(model_dir, "Model_full_source_rainfall_terrain_fitkm_binomial_BKMR.RData")
model_to_load <- if (nzchar(EXISTING_MODEL_FILE)) EXISTING_MODEL_FILE else model_file
if (nzchar(EXISTING_MODEL_FILE) && !file.exists(EXISTING_MODEL_FILE)) {
  stop("EXISTING_MODEL_FILE不存在，请核对路径。")
}
if ((REUSE_COMPATIBLE_MODEL || nzchar(EXISTING_MODEL_FILE)) && file.exists(model_to_load)) {
  model_env <- new.env(parent = baseenv())
  load(model_to_load, envir = model_env)
  if (!exists("fitkm", envir = model_env, inherits = FALSE)) stop("模型文件缺少fitkm对象。")
  fitkm <- get("fitkm", envir = model_env, inherits = FALSE)
  if (!identical(fitkm$family, "binomial") ||
      !isTRUE(all.equal(as.numeric(fitkm$y), y)) ||
      !identical(colnames(as.matrix(fitkm$Z)), colnames(Z)) ||
      !isTRUE(all.equal(unname(as.matrix(fitkm$Z)), unname(Z), tolerance = 1e-10)) ||
      nrow(as.matrix(fitkm$r)) != iter_num) {
    stop("缓存模型与训练数据、变量顺序、扰动或迭代数不一致。请核实原模型，或使用新的输出目录重新拟合。")
  }
  cat("已复用兼容模型：", model_to_load, "\n")
} else {
  fitkm <- kmbayes(
    y = y, Z = Z, X = NULL, iter = iter_num, verbose = TRUE,
    varsel = FALSE, family = "binomial", est.h = TRUE
  )
}
save(fitkm, Z_raw, scale_center, scale_sd, file = model_file)

cat("模型拟合完成，模型文件已保存至：", model_file, "\n")

# ============================================================
# 7. 绘图主题与工具函数
# ============================================================

curve_color <- "#9C1A1C"
positive_bg <- "#E6F4EA"
negative_bg <- "#FCE8E6"
fill_colors <- c("#48A597", "#F7F7F7", "#9C1A1C")

theme_pub <- theme_bw(base_size = 11) +
  theme(
    plot.title = element_text(size = 13, face = "bold", hjust = 0),
    axis.title = element_text(size = 11, face = "bold"),
    axis.text = element_text(size = 9, color = "black"),
    panel.grid.major = element_line(color = "#EEEEEE", linewidth = 0.35),
    panel.grid.minor = element_line(color = "#F3F3F3", linewidth = 0.25),
    panel.border = element_rect(color = "black", linewidth = 0.5),
    strip.background = element_rect(fill = "#E6E6E6", color = "black", linewidth = 0.4),
    strip.text = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    legend.background = element_rect(fill = "white", color = "#CCCCCC")
  )

find_zero_crossings <- function(x, y) {
  idx <- which(diff(sign(y)) != 0)
  if (length(idx) == 0) return(numeric(0))
  
  crossings <- c()
  for (i in idx) {
    x1 <- x[i]
    x2 <- x[i + 1]
    y1 <- y[i]
    y2 <- y[i + 1]
    if (is.na(y1) || is.na(y2)) next
    if ((y2 - y1) == 0) next
    x0 <- x1 + (0 - y1) * (x2 - x1) / (y2 - y1)
    crossings <- c(crossings, x0)
  }
  
  crossings
}

make_safe_name <- function(x) {
  x <- as.character(x)
  x <- gsub("[^A-Za-z0-9_\\-]+", "_", x)
  x <- gsub("_+", "_", x)
  x
}

write_df_xlsx <- function(df, file) {
  write.xlsx(df, file = file, overwrite = TRUE)
}

write_bivar_origin_xlsx <- function(df_pair, file) {
  wb <- createWorkbook()
  
  addWorksheet(wb, "Long_data")
  writeData(wb, "Long_data", df_pair)
  
  df_matrix <- df_pair %>%
    select(x_raw, y_raw, est) %>%
    mutate(
      x_raw = round(x_raw, 8),
      y_raw = round(y_raw, 8)
    ) %>%
    pivot_wider(
      names_from = x_raw,
      values_from = est
    ) %>%
    arrange(y_raw)
  
  addWorksheet(wb, "Matrix_est")
  writeData(wb, "Matrix_est", df_matrix)
  
  saveWorkbook(wb, file, overwrite = TRUE)
}

# ============================================================
# 8. 单变量响应曲线：所有单图 + 组合图 
# ============================================================

cat("\n开始生成单变量响应图和数据...\n")

pred.uni <- PredictorResponseUnivar(
  fit = fitkm, method = "approx", ngrid = 50, q.fixed = 0.5,
  center = TRUE,
  sel = seq.int(floor(iter_num * THRESHOLD_BURN_FRACTION) + 1L, iter_num)
)

pred.uni$variable <- as.character(pred.uni$variable)
pred.uni$raw_x <- mapply(
  inverse_z_to_raw,
  pred.uni$variable,
  pred.uni$z
)

pred.uni$variable_label <- label_var(pred.uni$variable)
pred.uni$axis_label <- axis_label_var(pred.uni$variable)
pred.uni$lower95 <- pred.uni$est - 1.96 * pred.uni$se
pred.uni$upper95 <- pred.uni$est + 1.96 * pred.uni$se

write_df_xlsx(
  pred.uni,
  file.path(data_dir, "univariate_response_all_origin_data.xlsx")
)

write.csv(
  pred.uni,
  file.path(data_dir, "univariate_response_all_origin_data.csv"),
  row.names = FALSE
)

# 单变量单图
univar_threshold_records <- list()

for (v in unique(pred.uni$variable)) {
  df_v <- pred.uni %>%
    filter(variable == v) %>%
    arrange(raw_x)
  
  cross_vals <- find_zero_crossings(df_v$raw_x, df_v$est)
  
  if (length(cross_vals) > 0) {
    threshold_df <- data.frame(
      Variable = v,
      Variable_label = unique(df_v$variable_label),
      Threshold_raw_value = cross_vals
    )
    univar_threshold_records[[v]] <- threshold_df
  }
  
  write_df_xlsx(
    df_v,
    file.path(univar_single_data_dir, paste0("univariate_", make_safe_name(v), "_origin_data.xlsx"))
  )
  
  x_min <- min(df_v$raw_x, na.rm = TRUE)
  x_max <- max(df_v$raw_x, na.rm = TRUE)
  y_min <- min(df_v$lower95, na.rm = TRUE)
  y_max <- max(df_v$upper95, na.rm = TRUE)
  
  x_margin <- (x_max - x_min) * 0.05
  y_margin <- (y_max - y_min) * 0.10
  
  p <- ggplot(df_v, aes(x = raw_x, y = est)) +
    annotate(
      "rect",
      xmin = -Inf, xmax = Inf,
      ymin = 0, ymax = Inf,
      fill = positive_bg,
      alpha = 0.55
    ) +
    annotate(
      "rect",
      xmin = -Inf, xmax = Inf,
      ymin = -Inf, ymax = 0,
      fill = negative_bg,
      alpha = 0.55
    ) +
    geom_hline(
      yintercept = 0,
      color = "gray55",
      linetype = "dashed",
      linewidth = 0.45
    ) +
    geom_ribbon(
      aes(ymin = lower95, ymax = upper95),
      fill = "gray75",
      alpha = 0.55
    ) +
    geom_line(
      color = curve_color,
      linewidth = 0.85
    ) +
    theme_pub +
    labs(
      x = axis_label_var(v),
      y = "h(z) on probit scale",
      title = label_var(v)
    ) +
    coord_cartesian(
      xlim = c(x_min - x_margin, x_max + x_margin),
      ylim = c(y_min - y_margin, y_max + y_margin)
    )
  
  if (length(cross_vals) > 0) {
    for (k in seq_along(cross_vals)) {
      y_pos <- ifelse(k %% 2 == 1, 0.08 * y_max, -0.08 * abs(y_min))
      p <- p +
        geom_vline(
          xintercept = cross_vals[k],
          color = curve_color,
          linetype = "dashed",
          linewidth = 0.45
        ) +
        annotate(
          "text",
          x = cross_vals[k],
          y = y_pos,
          label = sprintf("%.2f", cross_vals[k]),
          color = curve_color,
          size = 3,
          fontface = "bold"
        )
    }
  }
  
  ggsave(
    filename = file.path(univar_single_fig_dir, paste0("univariate_", make_safe_name(v), ".png")),
    plot = p,
    width = 5,
    height = 5,
    dpi = 600
  )
}

threshold_all <- bind_rows(univar_threshold_records)

if (is.null(threshold_all) || nrow(threshold_all) == 0) {
  threshold_all <- data.frame(
    Variable = character(0),
    Variable_label = character(0),
    Threshold_raw_value = numeric(0)
  )
}

write_df_xlsx(
  threshold_all,
  file.path(data_dir, "univariate_zero_crossing_thresholds.xlsx")
)

# 单变量组合图
p_uni_facet <- ggplot(pred.uni, aes(x = raw_x, y = est)) +
  annotate(
    "rect",
    xmin = -Inf, xmax = Inf,
    ymin = 0, ymax = Inf,
    fill = positive_bg,
    alpha = 0.55
  ) +
  annotate(
    "rect",
    xmin = -Inf, xmax = Inf,
    ymin = -Inf, ymax = 0,
    fill = negative_bg,
    alpha = 0.55
  ) +
  geom_hline(
    yintercept = 0,
    color = "gray55",
    linetype = "dashed",
    linewidth = 0.45
  ) +
  geom_ribbon(
    aes(ymin = lower95, ymax = upper95),
    fill = "gray75",
    alpha = 0.55
  ) +
  geom_line(
    color = curve_color,
    linewidth = 0.85
  ) +
  facet_wrap(~ variable_label, ncol = 3, scales = "free_x") +
  theme_pub +
  labs(
    x = "Original variable value",
    y = "h(z) on probit scale",
    title = "BKMR univariate exposure-response functions"
  )

ggsave(
  filename = file.path(fig_dir, "univariate_response_combined.png"),
  plot = p_uni_facet,
  width = 12,
  height = 8,
  dpi = 600
)

cat("单变量响应图和数据已完成。\n")

# ============================================================
# 9. 双变量响应面：所有两两组合，单图 + 组合图 + Origin数据
# ============================================================

cat("\n开始生成所有双变量响应面...\n")

pred.bi <- PredictorResponseBivar(
  fit = fitkm,
  min.plot.dist = MIN_PLOT_DIST
)

pred.bi$variable1 <- as.character(pred.bi$variable1)
pred.bi$variable2 <- as.character(pred.bi$variable2)

pred.bi$x_raw <- mapply(
  inverse_z_to_raw,
  pred.bi$variable1,
  pred.bi$z1
)

pred.bi$y_raw <- mapply(
  inverse_z_to_raw,
  pred.bi$variable2,
  pred.bi$z2
)

pred.bi$variable1_label <- label_var(pred.bi$variable1)
pred.bi$variable2_label <- label_var(pred.bi$variable2)
pred.bi$pair_label <- paste0(pred.bi$variable1_label, " × ", pred.bi$variable2_label)

write_df_xlsx(
  pred.bi,
  file.path(data_dir, "bivariate_response_all_long_origin_data.xlsx")
)

write.csv(
  pred.bi,
  file.path(data_dir, "bivariate_response_all_long_origin_data.csv"),
  row.names = FALSE
)

# 所有双变量单图
all_pair_names <- unique(pred.bi[, c("variable1", "variable2", "pair_label")])

for (i in seq_len(nrow(all_pair_names))) {
  v1 <- all_pair_names$variable1[i]
  v2 <- all_pair_names$variable2[i]
  pair_label_i <- all_pair_names$pair_label[i]
  
  df_pair <- pred.bi %>%
    filter(variable1 == v1, variable2 == v2) %>%
    arrange(x_raw, y_raw)
  
  pair_safe <- paste0(make_safe_name(v1), "_x_", make_safe_name(v2))
  
  write_bivar_origin_xlsx(
    df_pair,
    file.path(bivar_single_data_dir, paste0("bivariate_", pair_safe, "_origin_data.xlsx"))
  )
  
  q_vals <- quantile(df_pair$est, probs = c(0.25, 0.5, 0.75), na.rm = TRUE)
  
  p <- ggplot(df_pair, aes(x = x_raw, y = y_raw, fill = est)) +
    geom_tile() +
    geom_contour(
      aes(z = est),
      breaks = q_vals[1],
      color = "#2166AC",
      linetype = "dashed",
      linewidth = 0.45
    ) +
    geom_contour(
      aes(z = est),
      breaks = q_vals[2],
      color = "#48A597",
      linetype = "solid",
      linewidth = 0.45
    ) +
    geom_contour(
      aes(z = est),
      breaks = q_vals[3],
      color = "#9C1A1C",
      linetype = "dashed",
      linewidth = 0.45
    ) +
    scale_fill_gradientn(
      colours = fill_colors,
      name = "h(z)"
    ) +
    theme_pub +
    labs(
      x = axis_label_var(v1),
      y = axis_label_var(v2),
      title = pair_label_i
    )
  
  ggsave(
    filename = file.path(bivar_single_fig_dir, paste0("bivariate_", pair_safe, ".png")),
    plot = p,
    width = 6,
    height = 5,
    dpi = 600
  )
}

# 所有双变量组合图
n_pairs <- nrow(all_pair_names)
ncol_pair <- 3
nrow_pair <- ceiling(n_pairs / ncol_pair)

p_bivar_all <- ggplot(pred.bi, aes(x = x_raw, y = y_raw, fill = est)) +
  geom_tile() +
  scale_fill_gradientn(
    colours = fill_colors,
    name = "h(z)"
  ) +
  facet_wrap(~ pair_label, ncol = ncol_pair, scales = "free") +
  theme_pub +
  labs(
    x = "Original value of variable 1",
    y = "Original value of variable 2",
    title = "BKMR bivariate response surfaces"
  )

ggsave(
  filename = file.path(fig_dir, "bivariate_response_all_pairs_combined.png"),
  plot = p_bivar_all,
  width = 5.2 * ncol_pair,
  height = 4.2 * nrow_pair,
  dpi = 600
)

cat("所有双变量响应面图和数据已完成。\n")

# ============================================================
# 10. 条件双变量响应曲线：所有两两组合，单图 + 组合图 + Origin数据
# ============================================================

cat("\n开始生成 BKMR conditional bivariate response curves...\n")

pred.cond <- PredictorResponseBivarLevels(
  pred.resp.df = pred.bi,
  Z = Z,
  qs = c(0.1, 0.5, 0.9)
)

pred.cond$variable1 <- as.character(pred.cond$variable1)
pred.cond$variable2 <- as.character(pred.cond$variable2)
pred.cond$quantile <- as.character(pred.cond$quantile)

pred.cond$x_raw <- mapply(
  inverse_z_to_raw,
  pred.cond$variable1,
  pred.cond$z1
)

pred.cond$variable1_label <- label_var(pred.cond$variable1)
pred.cond$variable2_label <- label_var(pred.cond$variable2)
pred.cond$pair_label <- paste0(pred.cond$variable1_label, " × ", pred.cond$variable2_label)

write_df_xlsx(
  pred.cond,
  file.path(data_dir, "conditional_bivariate_response_all_origin_data.xlsx")
)

write.csv(
  pred.cond,
  file.path(data_dir, "conditional_bivariate_response_all_origin_data.csv"),
  row.names = FALSE
)

# 条件曲线单图
cond_pair_names <- unique(pred.cond[, c("variable1", "variable2", "pair_label")])

for (i in seq_len(nrow(cond_pair_names))) {
  v1 <- cond_pair_names$variable1[i]
  v2 <- cond_pair_names$variable2[i]
  pair_label_i <- cond_pair_names$pair_label[i]
  
  df_pair <- pred.cond %>%
    filter(variable1 == v1, variable2 == v2) %>%
    arrange(quantile, x_raw)
  
  pair_safe <- paste0(make_safe_name(v1), "_x_", make_safe_name(v2))
  
  write_df_xlsx(
    df_pair,
    file.path(cond_single_data_dir, paste0("conditional_bivariate_", pair_safe, "_origin_data.xlsx"))
  )
  
  p <- ggplot(df_pair, aes(x = x_raw, y = est, color = quantile)) +
    geom_hline(
      yintercept = 0,
      color = "gray55",
      linetype = "dashed",
      linewidth = 0.4
    ) +
    geom_line(linewidth = 0.85) +
    scale_color_manual(
      values = c("0.1" = "#2166AC", "0.5" = "#48A597", "0.9" = "#9C1A1C")
    ) +
    theme_pub +
    labs(
      x = axis_label_var(v1),
      y = "h(z)",
      color = "Quantile of variable 2",
      title = pair_label_i
    )
  
  ggsave(
    filename = file.path(cond_single_fig_dir, paste0("conditional_bivariate_", pair_safe, ".png")),
    plot = p,
    width = 6,
    height = 5,
    dpi = 600
  )
}

# 条件曲线组合图
n_cond_pairs <- nrow(cond_pair_names)
ncol_cond <- 3
nrow_cond <- ceiling(n_cond_pairs / ncol_cond)

p_cond_all <- ggplot(pred.cond, aes(x = x_raw, y = est, color = quantile)) +
  geom_hline(
    yintercept = 0,
    color = "gray55",
    linetype = "dashed",
    linewidth = 0.4
  ) +
  geom_line(linewidth = 0.75) +
  scale_color_manual(
    values = c("0.1" = "#2166AC", "0.5" = "#48A597", "0.9" = "#9C1A1C")
  ) +
  facet_wrap(~ pair_label, ncol = ncol_cond, scales = "free_x") +
  theme_pub +
  labs(
    x = "Original value of variable 1",
    y = "h(z)",
    color = "Quantile of variable 2",
    title = "BKMR conditional bivariate response curves"
  )

ggsave(
  filename = file.path(fig_dir, "conditional_bivariate_response_all_pairs_combined.png"),
  plot = p_cond_all,
  width = 5.2 * ncol_cond,
  height = 4.2 * nrow_cond,
  dpi = 600
)

cat("条件双变量响应曲线图和数据已完成。\n")

# ============================================================
# 11. 单变量风险摘要图：SHAP风格美化版
# ============================================================

cat("\n开始生成单变量风险摘要...\n")


risks.singvar <- SingVarRiskSummaries(
  fit = fitkm,
  y = y,
  Z = Z,
  X = NULL,
  qs.diff = c(0.25, 0.75),
  q.fixed = c(0.25, 0.50, 0.75),
  method = "exact"
)

risks.singvar <- as.data.frame(risks.singvar)

# 统一变量名、标签和置信区间
risks.singvar$variable <- as.character(risks.singvar$variable)
risks.singvar$variable_label <- label_var(risks.singvar$variable)
risks.singvar$q.fixed <- as.numeric(as.character(risks.singvar$q.fixed))

# bkmr 输出中的不确定性列通常为 sd；这里构建 95% 区间
if (!"sd" %in% names(risks.singvar)) {
  stop("SingVarRiskSummaries 输出中没有 sd 列，无法构建 95% 置信/可信区间。请检查 bkmr 输出结构。")
}

risks.singvar$lower95 <- risks.singvar$est - 1.96 * risks.singvar$sd
risks.singvar$upper95 <- risks.singvar$est + 1.96 * risks.singvar$sd

# 将 q.fixed 统一整理为 0.25 / 0.50 / 0.75
risks.singvar$q.fixed <- factor(
  risks.singvar$q.fixed,
  levels = c(0.25, 0.50, 0.75),
  labels = c("0.25", "0.50", "0.75")
)

# 导出单变量风险摘要 Origin 数据
write_df_xlsx(
  risks.singvar,
  file.path(data_dir, "single_variable_risk_summaries_origin_data.xlsx")
)

write.csv(
  risks.singvar,
  file.path(data_dir, "single_variable_risk_summaries_origin_data.csv"),
  row.names = FALSE
)

# 计算每个变量的相对贡献比例。
# global_score = 三种固定分位条件下 abs(response difference) 的平均值。
risk_importance <- risks.singvar %>%
  group_by(variable_label) %>%
  summarise(
    global_score = mean(abs(est), na.rm = TRUE),
    max_upper = max(upper95, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    percent = ifelse(
      sum(global_score, na.rm = TRUE) > 0,
      100 * global_score / sum(global_score, na.rm = TRUE),
      0
    ),
    percent_label = sprintf("%.1f%%", percent)
  )

write_df_xlsx(
  risk_importance,
  file.path(data_dir, "single_variable_risk_importance_percent.xlsx")
)

# 按贡献由小到大设置因子顺序，这样 coord_flip 后最大值在最上方
risk_levels <- risk_importance %>%
  arrange(global_score) %>%
  pull(variable_label)

risks.singvar$variable_label <- factor(
  risks.singvar$variable_label,
  levels = risk_levels
)

risk_importance$variable_label <- factor(
  risk_importance$variable_label,
  levels = risk_levels
)

# 设置百分比标签位置
x_min <- min(c(risks.singvar$lower95, 0), na.rm = TRUE)
x_max_tmp <- max(c(risks.singvar$upper95, risk_importance$global_score), na.rm = TRUE)
x_range <- x_max_tmp - x_min
if (!is.finite(x_range) || x_range <= 0) {
  x_range <- 1
}

risk_importance <- risk_importance %>%
  mutate(
    label_x = pmax(global_score, max_upper, na.rm = TRUE) + 0.03 * x_range
  )

x_max <- max(risk_importance$label_x, na.rm = TRUE) + 0.08 * x_range

# SHAP风格颜色
risk_bar_fill <- "#DCE7F7"   # 浅蓝色背景条
risk_low_col  <- "#55AFA4"   # 低分位：青绿色
risk_mid_col  <- "#EBC7C6"   # 中分位：浅粉灰
risk_high_col <- "#9C1A1C"   # 高分位：深红色

# SHAP风格主题
# 若系统没有 Times New Roman，会自动使用可用字体，图件仍可正常输出。
theme_risk_shap <- theme_classic(base_size = 13, base_family = "Times New Roman") +
  theme(
    plot.title = element_text(
      size = 20,
      face = "bold",
      hjust = 0.5,
      color = "black",
      margin = margin(b = 8)
    ),
    axis.title.x = element_text(
      size = 16,
      face = "bold",
      color = "black",
      margin = margin(t = 10)
    ),
    axis.title.y = element_text(
      size = 16,
      face = "bold",
      color = "black",
      margin = margin(r = 10)
    ),
    axis.text.x = element_text(
      size = 13,
      face = "bold",
      color = "black"
    ),
    axis.text.y = element_text(
      size = 13,
      face = "bold",
      color = "black"
    ),
    axis.line = element_line(color = "black", linewidth = 0.8),
    axis.ticks = element_line(color = "black", linewidth = 0.8),
    axis.ticks.length = unit(0.18, "cm"),
    panel.grid.major.y = element_line(
      color = "#DDDDDD",
      linetype = "dashed",
      linewidth = 0.45
    ),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "right",
    legend.title = element_text(
      size = 13,
      face = "bold",
      color = "black"
    ),
    legend.text = element_text(
      size = 12,
      face = "bold",
      color = "black"
    ),
    legend.background = element_blank(),
    plot.margin = margin(10, 35, 10, 10)
  )

# 绘图
p_risk <- ggplot() +
  # 浅蓝色背景条，类似 SHAP 图中的 mean impact bar
  geom_col(
    data = risk_importance,
    aes(x = variable_label, y = global_score),
    fill = risk_bar_fill,
    width = 0.62,
    alpha = 0.85
  ) +
  # 0线
  geom_hline(
    yintercept = 0,
    color = "gray45",
    linewidth = 0.65
  ) +
  # 三个固定分位数下的风险差异及95%区间
  geom_pointrange(
    data = risks.singvar,
    aes(
      x = variable_label,
      y = est,
      ymin = lower95,
      ymax = upper95,
      color = q.fixed
    ),
    position = position_dodge(width = 0.58),
    linewidth = 0.85,
    fatten = 2.6,
    alpha = 0.95
  ) +
  # 百分比标签
  geom_text(
    data = risk_importance,
    aes(
      x = variable_label,
      y = label_x,
      label = percent_label
    ),
    hjust = 0,
    size = 5.0,
    fontface = "bold",
    family = "Times New Roman",
    color = "black"
  ) +
  coord_flip(clip = "off") +
  scale_y_continuous(
    limits = c(x_min, x_max),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  scale_color_manual(
    values = c(
      "0.25" = risk_low_col,
      "0.50" = risk_mid_col,
      "0.75" = risk_high_col
    ),
    breaks = c("0.75", "0.50", "0.25"),
    labels = c("0.75  High", "0.50", "0.25  Low"),
    name = "Fixed quantile"
  ) +
  theme_risk_shap +
  labs(
    x = "Variable",
    y = "Response difference",
    title = "BKMR single-variable risk summaries"
  )

# 同时输出美化版和普通版，防止字体或主题导致某些系统显示异常
ggsave(
  filename = file.path(fig_dir, "single_variable_risk_summaries_SHAP_style.png"),
  plot = p_risk,
  width = 10,
  height = 7,
  dpi = 600
)


# 传统风格备份图
p_risk_basic <- ggplot(
  risks.singvar,
  aes(
    x = variable_label,
    y = est,
    ymin = lower95,
    ymax = upper95,
    color = q.fixed
  )
) +
  geom_hline(
    yintercept = 0,
    color = "gray55",
    linetype = "dashed",
    linewidth = 0.4
  ) +
  geom_pointrange(
    position = position_dodge(width = 0.75),
    linewidth = 0.7
  ) +
  coord_flip() +
  scale_color_manual(
    values = c(
      "0.25" = "#2166AC",
      "0.50" = "#48A597",
      "0.75" = "#9C1A1C"
    ),
    name = "Fixed quantile"
  ) +
  theme_pub +
  labs(
    x = "Variable",
    y = "Response difference",
    title = "BKMR single-variable risk summaries"
  )

ggsave(
  filename = file.path(fig_dir, "single_variable_risk_summaries_basic.png"),
  plot = p_risk_basic,
  width = 10,
  height = 7,
  dpi = 600
)

cat("单变量风险摘要图和数据已完成。\n")

# ============================================================
# 12. 总Excel汇总文件
# ============================================================

cat("\n开始生成总Excel汇总文件...\n")

master_file <- file.path(out_dir, "BKMR_all_figures_origin_data_master.xlsx")

wb <- createWorkbook()

addWorksheet(wb, "Standardization")
writeData(
  wb,
  "Standardization",
  data.frame(
    Variable = names(scale_center),
    Label = label_var(names(scale_center)),
    Center = as.numeric(scale_center),
    SD = as.numeric(scale_sd),
    Log1p_used = names(scale_center) %in% LOG_VARS
  )
)

addWorksheet(wb, "Variable_groups")
writeData(
  wb,
  "Variable_groups",
  data.frame(
    Group = c("Rainfall", "Source", "Terrain_channel"),
    Variables = c(
      paste(rain_names, collapse = ", "),
      paste(source_names, collapse = ", "),
      paste(terrain_names, collapse = ", ")
    ),
    Variable_meaning = c(
      paste(label_var(rain_names), collapse = "; "),
      paste(label_var(source_names), collapse = "; "),
      paste(label_var(terrain_names), collapse = "; ")
    )
  )
)

addWorksheet(wb, "Univariate_all")
writeData(wb, "Univariate_all", pred.uni)

addWorksheet(wb, "Zero_crossing")
writeData(wb, "Zero_crossing", threshold_all)

addWorksheet(wb, "Bivariate_all_long")
writeData(wb, "Bivariate_all_long", pred.bi)

addWorksheet(wb, "Conditional_all")
writeData(wb, "Conditional_all", pred.cond)

addWorksheet(wb, "Risk_summary")
writeData(wb, "Risk_summary", risks.singvar)

addWorksheet(wb, "Data_diagnosis_basic")
writeData(
  wb,
  "Data_diagnosis_basic",
  data.frame(
    Item = c("Sample_before", "Sample_after", "N_controls", "Iter_num", "Min_plot_dist"),
    Value = c(n_before, n_after, ncol(Z_raw), iter_num, as.character(MIN_PLOT_DIST))
  )
)

saveWorkbook(wb, master_file, overwrite = TRUE)

cat("总Excel已保存至：", master_file, "\n")

# ============================================================
# 13. 完成提示
# ============================================================

cat("\n============================================================\n")
cat("BKMR 1000次训练 + 单变量/双变量/条件曲线 + Origin数据导出完成！\n")
cat("模型文件：", model_file, "\n")
cat("总输出目录：", out_dir, "\n")
cat("图件目录：", fig_dir, "\n")
cat("Origin数据目录：", data_dir, "\n")
cat("总Excel：", master_file, "\n")
cat("============================================================\n")

# ============================================================
# 14. Threshold review: posterior uncertainty and bootstrap
# Definition: a UNIQUE INTERIOR NEGATIVE-TO-POSITIVE crossing of
# the grid-mean-centered conditional response, with linear interpolation.
# Multiple / absent / boundary / tangential roots are retained as statuses.
# This is a statistical reference value, not a physical failure threshold.
# ============================================================

review_roots <- function(x, response, zero_tol = 0) {
  empty <- data.frame(root = numeric(), direction = character(),
                      stringsAsFactors = FALSE)
  if (length(x) != length(response) || length(x) < 3L ||
      any(!is.finite(x)) || any(!is.finite(response))) {
    return(list(status = "invalid_curve", threshold = NA_real_, roots = empty))
  }
  ord <- order(x)
  x <- x[ord]
  response <- response[ord]
  if (anyDuplicated(x)) stop("Threshold grid contains duplicate x values.")
  if (all(abs(response) <= zero_tol)) {
    return(list(status = "flat_curve", threshold = NA_real_, roots = empty))
  }
  sg <- sign(response)
  sg[abs(response) <= zero_tol] <- 0
  records <- list()
  add <- function(value, direction) {
    records[[length(records) + 1L]] <<-
      data.frame(root = value, direction = direction, stringsAsFactors = FALSE)
  }
  for (i in seq_len(length(x) - 1L)) {
    if (sg[i] * sg[i + 1L] < 0) {
      root <- x[i] - response[i] * (x[i + 1L] - x[i]) /
        (response[i + 1L] - response[i])
      add(root, if (sg[i] < 0) "upward" else "downward")
    }
  }
  zeros <- which(sg == 0)
  if (length(zeros)) {
    groups <- split(zeros, cumsum(c(TRUE, diff(zeros) != 1L)))
    for (ii in groups) {
      if (length(ii) > 1L) {
        add(mean(x[ii]), "zero_plateau")
      } else {
        i <- ii[1L]
        if (i == 1L || i == length(x)) {
          add(x[i], "boundary")
        } else if (sg[i - 1L] < 0 && sg[i + 1L] > 0) {
          add(x[i], "upward")
        } else if (sg[i - 1L] > 0 && sg[i + 1L] < 0) {
          add(x[i], "downward")
        } else {
          add(x[i], "touch")
        }
      }
    }
  }
  roots <- if (length(records)) do.call(rbind, records) else empty
  if (nrow(roots)) roots <- roots[order(roots$root), , drop = FALSE]
  status <- if (!nrow(roots)) "no_crossing" else if (nrow(roots) > 1L) {
    "multiple_crossings"
  } else if (roots$direction[1L] == "upward") {
    "unique_upward"
  } else roots$direction[1L]
  threshold <- if (identical(status, "unique_upward")) roots$root[1L] else NA_real_
  list(status = status, threshold = threshold, roots = roots)
}

review_root_record <- function(x, response) {
  rr <- review_roots(x, response)
  data.frame(status = rr$status, threshold = rr$threshold,
             n_roots = nrow(rr$roots),
             all_roots = paste(format(rr$roots$root, digits = 12), collapse = ";"),
             root_directions = paste(rr$roots$direction, collapse = ";"),
             stringsAsFactors = FALSE)
}

review_self_tests <- function() {
  stopifnot(review_roots(c(0, 1, 2), c(-1, 1, 3))$threshold == 0.5)
  stopifnot(review_roots(0:2, c(-1, 0, 1))$threshold == 1)
  stopifnot(review_roots(0:2, c(1, 2, 3))$status == "no_crossing")
  stopifnot(review_roots(0:3, c(-1, 1, -1, 1))$status == "multiple_crossings")
  stopifnot(review_roots(0:2, c(0, 1, 2))$status == "boundary")
  stopifnot(review_roots(0:2, c(1, 0, 1))$status == "touch")
  stopifnot(review_roots(0:3, c(-1, 0, 0, 1))$status == "zero_plateau")
  stopifnot(review_roots(0:2, c(0, 0, 0))$status == "flat_curve")
  stopifnot(review_roots(0:2, c(1, 0, -1))$status == "downward")
  stopifnot(review_roots(0:2, c(-1, NA, 1))$status == "invalid_curve")
  message("Threshold root self-tests passed.")
}

review_sel <- function(fit, burn_fraction, max_draws = Inf) {
  niter <- if (!is.null(fit$iter)) as.integer(fit$iter) else nrow(fit$r)
  if (length(niter) != 1L || !is.finite(niter) || niter < 4L) {
    stop("Cannot determine the model's MCMC iteration count.")
  }
  if (!is.finite(burn_fraction) || burn_fraction < 0 || burn_fraction >= 1) {
    stop("Burn-in fraction must lie in [0,1).")
  }
  sel <- seq.int(floor(niter * burn_fraction) + 1L, niter)
  if (is.finite(max_draws) && length(sel) > max_draws) {
    if (max_draws < 2L) stop("At least two posterior iterations are required.")
    sel <- sel[unique(round(seq(1, length(sel), length.out = max_draws)))]
  }
  as.integer(sel)
}

review_xnew <- function(fit, n) {
  if (is.null(fit$X)) return(NULL)
  X <- as.matrix(fit$X)
  out <- matrix(rep(colMeans(X), each = n), nrow = n, ncol = ncol(X))
  colnames(out) <- colnames(X)
  out
}

review_draws <- function(fit, Znew, sel) {
  # All grid points for one curve are predicted in ONE joint call.
  # Splitting a curve across calls would lose within-curve covariance.
  out <- bkmr::SamplePred(fit = fit, Znew = Znew,
                         Xnew = review_xnew(fit, nrow(Znew)),
                         sel = sel, type = "link")
  out <- as.matrix(out)
  if (!identical(dim(out), c(length(sel), nrow(Znew)))) {
    stop("Unexpected SamplePred dimensions; inspect installed bkmr version.")
  }
  if (any(!is.finite(out))) stop("Non-finite posterior predictions.")
  # Center EACH JOINT DRAW, not just its posterior mean.
  sweep(out, 1L, rowMeans(out), FUN = "-")
}

review_grid <- function(raw_profile, variable, raw_x, center, scale_sd) {
  raw <- matrix(rep(as.numeric(raw_profile), each = length(raw_x)),
                nrow = length(raw_x), ncol = length(raw_profile))
  colnames(raw) <- names(raw_profile)
  raw[, variable] <- raw_x
  sweep(sweep(raw, 2L, center[colnames(raw)], "-"),
        2L, scale_sd[colnames(raw)], "/")
}

review_interval <- function(values, minimum = 20L) {
  values <- values[is.finite(values)]
  if (length(values) < minimum) {
    return(c(median = if (length(values)) median(values) else NA_real_,
             lower = NA_real_, upper = NA_real_, sd = NA_real_, iqr = NA_real_))
  }
  qq <- quantile(values, probs = c(0.025, 0.975), type = 7, names = FALSE)
  c(median = median(values), lower = qq[1L], upper = qq[2L],
    sd = sd(values), iqr = IQR(values))
}

review_atomic_rds <- function(object, path) {
  tmp <- tempfile("checkpoint_", tmpdir = dirname(path), fileext = ".rds")
  on.exit(unlink(tmp), add = TRUE)
  saveRDS(object, tmp)
  if (!file.copy(tmp, path, overwrite = TRUE)) stop("Could not save checkpoint.")
}

review_fingerprint <- function(object) {
  path <- tempfile(fileext = ".rds")
  on.exit(unlink(path), add = TRUE)
  saveRDS(object, path, version = 2)
  unname(tools::md5sum(path))
}

review_diagnostics <- function(fit, sel, destination) {
  mats <- list()
  for (name in c("lambda", "r")) {
    if (!is.null(fit[[name]])) {
      mat <- as.matrix(fit[[name]])
      colnames(mat) <- paste0(name, "_", seq_len(ncol(mat)))
      mats[[name]] <- mat
    }
  }
  if (!length(mats)) return(data.frame())
  samples <- do.call(cbind, mats)
  records <- lapply(seq_len(ncol(samples)), function(j) {
    x <- samples[sel, j]
    varied <- all(is.finite(x)) && is.finite(sd(x)) && sd(x) > 0
    ess <- if (varied && requireNamespace("coda", quietly = TRUE)) {
      tryCatch(as.numeric(coda::effectiveSize(coda::mcmc(x))),
               error = function(e) NA_real_)
    } else NA_real_
    lag1 <- if (varied && length(x) > 2L) cor(x[-1L], x[-length(x)]) else NA_real_
    data.frame(parameter = colnames(samples)[j], retained = length(x),
               ESS_coda = ess, lag1_autocorrelation = lag1,
               note = if (!varied) "constant_or_invalid" else if (is.na(ess)) {
                 "ESS_unavailable"
               } else "single_chain_diagnostic_not_proof_of_convergence")
  })
  tab <- do.call(rbind, records)
  write.csv(tab, file.path(destination, "MCMC_single_chain_diagnostics.csv"),
            row.names = FALSE)
  grDevices::png(file.path(destination, "MCMC_parameter_traces.png"),
                 width = 1600, height = 300 * ceiling(ncol(samples) / 2), res = 140)
  tryCatch({
    par(mfrow = c(ceiling(ncol(samples) / 2), 2), mar = c(3, 3, 2, 1))
    for (j in seq_len(ncol(samples))) {
      plot(samples[, j], type = "l", xlab = "Iteration", ylab = "Value",
           main = colnames(samples)[j])
      abline(v = min(sel) - 0.5, col = "red", lty = 2)
    }
  }, finally = grDevices::dev.off())
  if (any(is.na(tab$ESS_coda))) warning("Some parameter ESS values are unavailable.")
  if (any(tab$ESS_coda < 100, na.rm = TRUE)) {
    warning("Some ESS values are below 100. Inspect traces and extend sampling; do not claim convergence.")
  }
  tab
}

run_threshold_review <- function(fit, raw_data, response, model_Z,
                                 scale_center, scale_sd, pred_uni, destination) {
  review_self_tests()
  variables <- THRESHOLD_VARIABLES
  if (!all(variables %in% names(raw_data))) {
    stop("Missing threshold predictors: ", paste(setdiff(variables, names(raw_data)), collapse = ", "))
  }
  if (length(LOG_VARS)) stop("Threshold review currently requires LOG_VARS = character(0).")
  if (!identical(colnames(model_Z), names(raw_data))) stop("Predictor order mismatch.")
  if (length(response) != nrow(raw_data) || any(!response %in% c(0, 1))) {
    stop("Training labels do not match the training predictors.")
  }
  if (!all(c(0, 1) %in% response)) stop("Both training classes are required.")
  if (!identical(colnames(as.matrix(fit$Z)), names(raw_data)) ||
      !isTRUE(all.equal(unname(as.matrix(fit$Z)), unname(model_Z), tolerance = 1e-10)) ||
      !isTRUE(all.equal(as.numeric(fit$y), as.numeric(response)))) {
    stop("Saved model inputs do not match this training dataset.")
  }
  dir.create(destination, recursive = TRUE, showWarnings = FALSE)
  posterior_dir <- file.path(destination, "posterior")
  boot_dir <- file.path(destination, "bootstrap")
  dir.create(posterior_dir, showWarnings = FALSE)
  dir.create(boot_dir, showWarnings = FALSE)
  sel <- review_sel(fit, THRESHOLD_BURN_FRACTION, THRESHOLD_POST_DRAWS)
  retained_all <- review_sel(fit, THRESHOLD_BURN_FRACTION)
  diag <- review_diagnostics(fit, retained_all, destination)
  writeLines(capture.output(sessionInfo()), file.path(destination, "sessionInfo.txt"))
  dput(fit$control.params, file = file.path(destination, "BKMR_control_params.R"))
  writeLines(c(
    "Threshold identification and uncertainty analysis",
    "Definition: unique interior negative-to-positive zero crossing of a conditional response centered by its arithmetic mean over the fixed grid.",
    "Adjacent points with opposite signs are connected by linear interpolation; exact single-node zeros are handled explicitly.",
    "No crossing, multiple roots, boundary roots, tangencies and zero plateaus are recorded and are not assigned a single threshold.",
    "The original 50-point grids and original model-median reference profile are fixed across resamples.",
    "Each posterior curve is generated jointly across its entire grid and centered separately before extracting its root.",
    "Posterior 95% credible intervals are empirical 2.5th and 97.5th percentiles CONDITIONAL ON a unique interior upward root.",
    "Bootstrap resamples are drawn with replacement within the two outcome classes, retaining the original class counts.",
    "Each bootstrap replicate recomputes its own standardization, reapplies the tiny input perturbation, refits the same BKMR specification and predicts on the FIXED raw-unit grid/profile.",
    "Bootstrap summaries describe sampling stability of the response-derived reference value. They are not posterior credible intervals.",
    "Report identification rates and fit failures alongside conditional intervals. Fewer than 20 identifiable values produce NA interval endpoints.",
    "These are statistical reference points, not inflection points, probability=0.5 thresholds or validated physical critical values.",
    "This stratified observation bootstrap does NOT account for spatial dependence. A spatial block bootstrap would answer a different robustness question.",
    "A single chain, its retained count, and its ESS do NOT establish convergence; no multi-chain R-hat or prior-sensitivity analysis is computed here.",
    "The final SISSO formula is NOT automatically refitted, and sensitivity of the final formula is NOT tested by this script.",
    "Check traces, ESS, identification fractions and agreement of the original approximate curve with the posterior mean curve before interpretation.",
    paste("Main MCMC iterations:", if (!is.null(fit$iter)) fit$iter else nrow(fit$r)),
    paste("Burn-in fraction:", THRESHOLD_BURN_FRACTION),
    paste("Retained MCMC states:", length(retained_all)),
    paste("Selected posterior predictive draws:", length(sel)),
    paste("Requested bootstrap replicates:", THRESHOLD_BOOT_REPS),
    paste("Bootstrap MCMC iterations:", THRESHOLD_BOOT_ITER),
    paste("Bootstrap posterior summary method:", THRESHOLD_BOOT_METHOD)
  ), file.path(destination, "METHOD_AND_INTERPRETATION.txt"))
  # Reference profile and raw-unit grids are FIXED across bootstrap replicates.
  # This avoids changing the estimand through resampled extrema or medians.
  raw_profile <- apply(model_Z, 2L, median) * scale_sd + scale_center
  raw_profile <- raw_profile[names(raw_data)]
  grids <- lapply(variables, function(v) {
    df <- pred_uni[as.character(pred_uni$variable) == v, , drop = FALSE]
    df[order(df$raw_x), , drop = FALSE]
  })
  names(grids) <- variables
  if (any(vapply(grids, nrow, integer(1)) < 3L)) stop("Missing prediction grids.")
  grid_records <- do.call(rbind, lapply(variables, function(v) {
    data.frame(variable = v, raw_x = grids[[v]]$raw_x)
  }))
  write.csv(grid_records, file.path(destination, "Fixed_raw_prediction_grids.csv"), row.names = FALSE)
  write.csv(data.frame(variable = names(raw_profile), fixed_raw_value = raw_profile),
            file.path(destination, "Fixed_reference_profile.csv"), row.names = FALSE)
  legacy_points <- do.call(rbind, lapply(variables, function(v) {
    cbind(data.frame(variable = v), review_root_record(grids[[v]]$raw_x, grids[[v]]$est))
  }))
  write.csv(legacy_points, file.path(destination, "Original_curve_zero_crossings.csv"), row.names = FALSE)
  post_summaries <- list()
  for (j in seq_along(variables)) {
    v <- variables[j]
    message("Posterior zero-crossing analysis: ", v, " (", length(sel), " draws)")
    xx <- grids[[v]]$raw_x
    Znew <- review_grid(raw_profile, v, xx, scale_center, scale_sd)
    set.seed(THRESHOLD_POST_SEED + j)
    draws <- review_draws(fit, Znew, sel)
    records <- do.call(rbind, lapply(seq_len(nrow(draws)), function(i) {
      cbind(data.frame(variable = v, draw = i, mcmc_iteration = sel[i]),
            review_root_record(xx, draws[i, ]))
    }))
    reference <- review_root_record(xx, colMeans(draws))
    reference$variable <- v
    ci <- review_interval(records$threshold)
    valid <- is.finite(records$threshold)
    old_point <- legacy_points$threshold[legacy_points$variable == v]
    post_summaries[[v]] <- data.frame(
      variable = v, original_approx_point = old_point,
      posterior_mean_curve_point = reference$threshold,
      posterior_mean_curve_status = reference$status,
      posterior_threshold_median = unname(ci["median"]),
      CrI95_lower_conditional_unique = unname(ci["lower"]),
      CrI95_upper_conditional_unique = unname(ci["upper"]),
      requested_draws = THRESHOLD_POST_DRAWS, actual_draws = nrow(draws),
      identifiable_draws = sum(valid), identifiable_fraction = mean(valid),
      multiple_crossing_fraction = mean(records$status == "multiple_crossings"),
      no_crossing_fraction = mean(records$status == "no_crossing"),
      other_invalid_fraction = mean(!valid & !records$status %in% c("multiple_crossings", "no_crossing")),
      mean_curve_max_abs_difference_from_original = max(abs(colMeans(draws) - grids[[v]]$est)))
    write.csv(records, file.path(posterior_dir, paste0(v, "_posterior_threshold_draws.csv")), row.names = FALSE)
    write.csv(as.data.frame(table(status = records$status)),
              file.path(posterior_dir, paste0(v, "_identification_status_counts.csv")), row.names = FALSE)
    curves <- data.frame(raw_x = xx, original_approx_est = grids[[v]]$est,
                         posterior_mean = colMeans(draws),
                         lower95_pointwise = apply(draws, 2L, quantile, 0.025),
                         upper95_pointwise = apply(draws, 2L, quantile, 0.975))
    write.csv(curves, file.path(posterior_dir, paste0(v, "_centered_posterior_curve.csv")), row.names = FALSE)
    saveRDS(list(variable = v, raw_x = xx, sel = sel, centered_joint_draws = draws),
            file.path(posterior_dir, paste0(v, "_joint_posterior_curves.rds")))
    if (mean(valid) < 0.9) warning(v, ": fewer than 90% of draws have one interior upward crossing. Report identification frequency with the conditional interval.")
  }
  posterior_summary <- do.call(rbind, post_summaries)
  rownames(posterior_summary) <- NULL
  write.csv(posterior_summary, file.path(destination, "Threshold_posterior_summary.csv"), row.names = FALSE)
  if (THRESHOLD_BOOT_REPS < 1L) {
    warning("Bootstrap disabled: no resampling stability analysis has been completed.")
    return(invisible(list(posterior = posterior_summary)))
  }
  signature <- review_fingerprint(list(schema = "threshold_review_v1",
    raw_data = raw_data, response = response, base_r = fit$r, base_lambda = fit$lambda,
    priors = fit$control.params, package_version = as.character(packageVersion("bkmr")),
    R_version = R.version.string, RNG_kind = RNGkind(), grid = grid_records, profile = raw_profile,
    burn_fraction = THRESHOLD_BURN_FRACTION, boot_iter = THRESHOLD_BOOT_ITER,
    boot_seed = THRESHOLD_BOOT_SEED, boot_method = THRESHOLD_BOOT_METHOD,
    jitter = jitter_sd, root_rule = "unique_interior_upward", min_interval_n = 20L,
    root_function = deparse(body(review_roots)),
    prediction_grid_function = deparse(body(review_grid))))
  checkpoint_dir <- file.path(boot_dir, paste0("checkpoints_", signature))
  dir.create(checkpoint_dir, showWarnings = FALSE)
  boot_records <- vector("list", THRESHOLD_BOOT_REPS)
  boot_indices <- vector("list", THRESHOLD_BOOT_REPS)
  for (b in seq_len(THRESHOLD_BOOT_REPS)) {
    file <- file.path(checkpoint_dir, sprintf("bootstrap_%04d.rds", b))
    cached <- if (file.exists(file)) tryCatch(readRDS(file), error = function(e) NULL) else NULL
    if (!is.null(cached) && identical(cached$signature, signature) &&
        (identical(cached$run_status, "completed") || !THRESHOLD_RETRY_FAILURES)) {
      result <- cached
      message("Bootstrap ", b, "/", THRESHOLD_BOOT_REPS, ": restored checkpoint")
    } else {
      message("Bootstrap ", b, "/", THRESHOLD_BOOT_REPS, ": refitting BKMR")
      time0 <- proc.time()[3L]
      sample_seed <- THRESHOLD_BOOT_SEED + b
      jitter_seed <- THRESHOLD_BOOT_SEED + 100000L + b
      fit_seed <- THRESHOLD_BOOT_SEED + 200000L + b
      set.seed(sample_seed)
      indices <- unlist(lapply(c(0, 1), function(label) {
        pool <- which(response == label)
        pool[sample.int(length(pool), length(pool), replace = TRUE)]
      }), use.names = FALSE)
      result <- tryCatch({
        raw_boot <- raw_data[indices, , drop = FALSE]
        y_boot <- response[indices]
        mu_boot <- vapply(raw_boot, mean, numeric(1))
        sd_boot <- vapply(raw_boot, sd, numeric(1))
        if (any(!is.finite(sd_boot)) || any(sd_boot <= 0)) stop("Zero-variance bootstrap predictor.")
        Z_boot <- as.matrix(scale(raw_boot, center = mu_boot, scale = sd_boot))
        set.seed(jitter_seed)
        Z_boot <- Z_boot + matrix(rnorm(length(Z_boot), sd = jitter_sd), nrow = nrow(Z_boot))
        colnames(Z_boot) <- names(raw_data)
        set.seed(fit_seed)
        boot_fit <- bkmr::kmbayes(y = y_boot, Z = Z_boot, X = NULL,
                                 iter = THRESHOLD_BOOT_ITER, family = "binomial",
                                 varsel = FALSE, est.h = TRUE, verbose = FALSE,
                                 control.params = fit$control.params)
        sel_boot <- review_sel(boot_fit, THRESHOLD_BURN_FRACTION)
        rows <- do.call(rbind, lapply(variables, function(v) {
          xx <- grids[[v]]$raw_x
          Znew <- review_grid(raw_profile, v, xx, mu_boot, sd_boot)
          prediction <- bkmr::ComputePostmeanHnew(fit = boot_fit, Znew = Znew,
                            sel = sel_boot, method = THRESHOLD_BOOT_METHOD)
          est <- as.numeric(prediction$postmean)
          if (any(!is.finite(est))) stop("Non-finite bootstrap response curve.")
          rec <- review_root_record(xx, est - mean(est))
          cbind(data.frame(variable = v), rec,
            data.frame(grid_fraction_outside_bootstrap_range = mean(xx < min(raw_boot[[v]]) | xx > max(raw_boot[[v]])),
              threshold_outside_bootstrap_range = if (is.finite(rec$threshold)) {
                rec$threshold < min(raw_boot[[v]]) || rec$threshold > max(raw_boot[[v]])
              } else NA))
        }))
        # Retain per-replicate ESS (when coda is available), not just successful roots.
        r_ess <- tryCatch({
          if (!requireNamespace("coda", quietly = TRUE)) NA_real_ else {
            vv <- cbind(as.matrix(boot_fit$lambda), as.matrix(boot_fit$r))[sel_boot, , drop = FALSE]
            variable_cols <- apply(vv, 2L, sd) > 0
            if (!any(variable_cols)) NA_real_ else {
              min(coda::effectiveSize(coda::mcmc(vv[, variable_cols, drop = FALSE])))
            }
          }
        }, error = function(e) NA_real_)
        if (THRESHOLD_SAVE_BOOT_MODELS) saveRDS(boot_fit, file.path(checkpoint_dir, sprintf("bootstrap_%04d_model.rds", b)))
        list(run_status = "completed", rows = rows, min_parameter_ESS = r_ess, error = "")
      }, error = function(e) {
        list(run_status = "failed", rows = do.call(rbind, lapply(variables, function(v) {
          data.frame(variable = v, status = "fit_or_prediction_failed", threshold = NA_real_,
                     n_roots = NA_integer_, all_roots = "", root_directions = "",
                     grid_fraction_outside_bootstrap_range = NA_real_,
                     threshold_outside_bootstrap_range = NA)
        })), min_parameter_ESS = NA_real_, error = conditionMessage(e))
      })
      result$signature <- signature
      result$indices <- indices
      result$seeds <- c(sample = sample_seed, jitter = jitter_seed, fit = fit_seed)
      result$elapsed_seconds <- unname(proc.time()[3L] - time0)
      review_atomic_rds(result, file)
    }
    rows <- result$rows
    rows$replicate <- b
    rows$run_status <- result$run_status
    rows$error <- result$error
    rows$min_parameter_ESS <- result$min_parameter_ESS
    rows$elapsed_seconds <- result$elapsed_seconds
    rows$sample_seed <- result$seeds["sample"]
    rows$jitter_seed <- result$seeds["jitter"]
    rows$fit_seed <- result$seeds["fit"]
    boot_records[[b]] <- rows
    boot_indices[[b]] <- data.frame(replicate = b, draw_position = seq_along(result$indices),
                                    original_training_row = result$indices)
    # Incremental results survive an interruption; all failures remain visible.
    write.csv(do.call(rbind, boot_records[seq_len(b)]),
              file.path(boot_dir, "Bootstrap_thresholds_progress.csv"), row.names = FALSE)
  }
  boot <- do.call(rbind, boot_records)
  indices <- do.call(rbind, boot_indices)
  write.csv(boot, file.path(boot_dir, "Bootstrap_thresholds_all.csv"), row.names = FALSE)
  write.csv(indices, file.path(boot_dir, "Bootstrap_resample_indices.csv"), row.names = FALSE)
  bootstrap_summary <- do.call(rbind, lapply(variables, function(v) {
    rows <- boot[boot$variable == v, , drop = FALSE]
    ci <- review_interval(rows$threshold)
    valid <- is.finite(rows$threshold)
    data.frame(variable = v, original_approx_point = legacy_points$threshold[legacy_points$variable == v],
      requested_replicates = THRESHOLD_BOOT_REPS,
      completed_fits = sum(rows$run_status == "completed"),
      failed_fits = sum(rows$run_status != "completed"),
      identifiable_replicates = sum(valid), identifiable_fraction_all_attempts = mean(valid),
      multiple_crossing_fraction_all_attempts = mean(rows$status == "multiple_crossings"),
      no_crossing_fraction_all_attempts = mean(rows$status == "no_crossing"),
      low_parameter_ESS_fraction = if (any(is.finite(rows$min_parameter_ESS))) {
        mean(rows$min_parameter_ESS[is.finite(rows$min_parameter_ESS)] < 100)
      } else NA_real_,
      bootstrap_median = unname(ci["median"]), bootstrap_SD = unname(ci["sd"]),
      bootstrap_IQR = unname(ci["iqr"]),
      percentile95_lower_conditional_unique = unname(ci["lower"]),
      percentile95_upper_conditional_unique = unname(ci["upper"]),
      roots_outside_bootstrap_range = sum(rows$threshold_outside_bootstrap_range, na.rm = TRUE))
  }))
  rownames(bootstrap_summary) <- NULL
  write.csv(bootstrap_summary, file.path(destination, "Threshold_bootstrap_summary.csv"), row.names = FALSE)
  interval_plot_data <- rbind(
    data.frame(variable = posterior_summary$variable, analysis = "Posterior: 95% CrI",
      median = posterior_summary$posterior_threshold_median,
      lower = posterior_summary$CrI95_lower_conditional_unique,
      upper = posterior_summary$CrI95_upper_conditional_unique),
    data.frame(variable = bootstrap_summary$variable, analysis = "Bootstrap: 95% percentile interval",
      median = bootstrap_summary$bootstrap_median,
      lower = bootstrap_summary$percentile95_lower_conditional_unique,
      upper = bootstrap_summary$percentile95_upper_conditional_unique))
  interval_plot_data$variable <- factor(interval_plot_data$variable,
    levels = c("B", "C", "D", "I"), labels = c("R24 (mm)", "SAR", "CKAI", "LCG"))
  p_intervals <- ggplot2::ggplot(interval_plot_data,
      ggplot2::aes(x = analysis, y = median, ymin = lower, ymax = upper)) +
    ggplot2::geom_pointrange(na.rm = TRUE) +
    ggplot2::facet_wrap(~ variable, scales = "free_y", ncol = 2) +
    ggplot2::theme_bw(base_size = 11) +
    ggplot2::labs(x = NULL, y = "Statistical response reference value",
      caption = "Intervals are conditional on a unique interior upward crossing. Report identification rates separately.") +
    ggplot2::theme(axis.text.x = ggplot2::element_text(size = 8))
  ggplot2::ggsave(file.path(destination, "Threshold_interval_comparison.png"),
                  p_intervals, width = 11, height = 7, dpi = 300)
  if (any(bootstrap_summary$identifiable_fraction_all_attempts < 0.9)) {
    warning("Bootstrap identifiability below 90% for some predictors; report the frequency and conditional nature of intervals.")
  }
  if (THRESHOLD_BOOT_REPS < 200L) warning("Fewer than 200 bootstrap replicates: treat percentile endpoints as provisional and check Monte Carlo stability.")
  workbook <- openxlsx::createWorkbook()
  for (sheet in c("Posterior_summary", "Bootstrap_summary", "Original_points", "MCMC_diagnostics")) {
    openxlsx::addWorksheet(workbook, sheet)
  }
  openxlsx::writeData(workbook, "Posterior_summary", posterior_summary)
  openxlsx::writeData(workbook, "Bootstrap_summary", bootstrap_summary)
  openxlsx::writeData(workbook, "Original_points", legacy_points)
  openxlsx::writeData(workbook, "MCMC_diagnostics", diag)
  openxlsx::saveWorkbook(workbook, file.path(destination, "Threshold_uncertainty_stability_summary.xlsx"), overwrite = TRUE)
  saveRDS(list(settings = list(burn_fraction = THRESHOLD_BURN_FRACTION,
    selected_posterior_iterations = sel, bootstrap_iter = THRESHOLD_BOOT_ITER,
    bootstrap_replicates = THRESHOLD_BOOT_REPS, signature = signature),
    posterior = posterior_summary, bootstrap = bootstrap_summary),
    file.path(destination, "Threshold_review_results.rds"))
  message("Threshold analysis finished. Results: ", destination)
  invisible(list(posterior = posterior_summary, bootstrap = bootstrap_summary))
}

if (RUN_THRESHOLD_REVIEW) {
  threshold_review_results <- run_threshold_review(
    fit = fitkm, raw_data = Z_raw, response = y, model_Z = Z,
    scale_center = scale_center, scale_sd = scale_sd,
    pred_uni = pred.uni, destination = file.path(out_dir, "03_threshold_review"))
}
